# Application de la méthode de classification Electre Tri 


## Installation

``` bash
# Install dependencies
pipenv install

cd pollster

# Serve on localhost:8000
python manage.py runserver
```

